Building CodeGeass
================

See doc/build-*.md for instructions on building the various
elements of the CodeGeass reference implementation of CodeGeass.
